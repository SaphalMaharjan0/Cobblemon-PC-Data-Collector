package com.sapha.cobblemoncollector;

import com.sapha.cobblemoncollector.collector.PokedexDataCollector;
import com.sapha.cobblemoncollector.collector.PokemonDataCollector;
import com.sapha.cobblemoncollector.command.CobblemonExportCommand;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;

public class CobblemonPCCollectorClient implements ClientModInitializer {

    public static final String MOD_ID = "cobblemon_pc_collector";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static class_304 exportKeyBinding;
    private static class_304 exportDexKeyBinding;

    @Override
    public void onInitializeClient() {
        LOGGER.info("[Cobblemon PC Collector] Initializing client-side data collector (v2.0.0)...");

        // 1. Register Client Commands (/collectpc, /cobbleexport, /collectdex, /cobbledex)
        CobblemonExportCommand.register();

        // 2. Register Hotkeys (P for PC, O for Pokédex)
        exportKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.cobblemon_pc_collector.export",
                GLFW.GLFW_KEY_P,
                "category.cobblemon_pc_collector"
        ));

        exportDexKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.cobblemon_pc_collector.export_pokedex",
                GLFW.GLFW_KEY_O,
                "category.cobblemon_pc_collector"
        ));

        // 3. Listen for Keybinding presses in client tick
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (exportKeyBinding.method_1436()) {
                if (client.field_1724 != null) {
                    performQuickExport(client);
                }
            }
            while (exportDexKeyBinding.method_1436()) {
                if (client.field_1724 != null) {
                    performQuickPokedexExport(client);
                }
            }
        });

        LOGGER.info("[Cobblemon PC Collector] Successfully loaded! Use /collectpc, /collectdex, or press 'P' / 'O' to export data.");
    }

    private void performQuickExport(class_310 client) {
        if (client.field_1724 == null) return;

        client.field_1724.method_7353(
                class_2561.method_43470("§6[Cobblemon Collector] §fExporting Pokémon data (JSON & CSV)..."),
                false
        );

        try {
            PokemonDataCollector.ExportResult result = PokemonDataCollector.exportData(true, true);

            if (result.totalCount() == 0) {
                client.field_1724.method_7353(
                        class_2561.method_43470("§e[Cobblemon Collector] §cNo Pokémon in memory yet! Please open your PC or Pasture once so your server sends your boxes.")
                                .method_27692(class_124.field_1054),
                        false
                );
                return;
            }

            client.field_1724.method_7353(
                    class_2561.method_43470(String.format("§a✔ Exported §e%d §aPokémon (§e%d §aParty, §e%d §aPC) to CSV and JSON!",
                            result.totalCount(), result.partyCount(), result.pcCount())),
                    false
            );

            if (result.csvFile() != null) {
                File folder = result.csvFile().getParentFile();
                class_5250 folderLink = class_2561.method_43470("§b[Click here to open folder: " + folder.getName() + "]")
                        .method_27694(style -> style
                                .method_10958(new class_2558(class_2558.class_2559.field_11746, folder.getAbsolutePath()))
                                .method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470("Open: " + folder.getAbsolutePath())))
                                .method_30938(true)
                                .method_10977(class_124.field_1075)
                        );
                client.field_1724.method_7353(folderLink, false);
            }
        } catch (Exception e) {
            LOGGER.error("Failed to export Pokémon data", e);
            client.field_1724.method_7353(
                    class_2561.method_43470("§c[Cobblemon Collector] Export failed: " + e.getMessage()),
                    false
            );
        }
    }

    private void performQuickPokedexExport(class_310 client) {
        if (client.field_1724 == null) return;

        client.field_1724.method_7353(
                class_2561.method_43470("§6[Cobblemon Collector] §fExporting CAUGHT Pokédex data (JSON & CSV)..."),
                false
        );

        try {
            PokedexDataCollector.PokedexExportResult result = PokedexDataCollector.exportData(true, true);

            if (result.totalCount() == 0) {
                client.field_1724.method_7353(
                        class_2561.method_43470("§e[Cobblemon Collector] §cNo caught Pokémon found in your Pokédex! Make sure your Pokédex has synced.")
                                .method_27692(class_124.field_1054),
                        false
                );
                return;
            }

            client.field_1724.method_7353(
                    class_2561.method_43470(String.format("§a✔ Exported §e%d §aCAUGHT Pokémon entries across §e%d §aunique species to CSV and JSON!",
                            result.totalCount(), result.uniqueSpeciesCount())),
                    false
            );

            if (result.csvFile() != null) {
                File folder = result.csvFile().getParentFile();
                class_5250 folderLink = class_2561.method_43470("§b[Click here to open folder: " + folder.getName() + "]")
                        .method_27694(style -> style
                                .method_10958(new class_2558(class_2558.class_2559.field_11746, folder.getAbsolutePath()))
                                .method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43470("Open: " + folder.getAbsolutePath())))
                                .method_30938(true)
                                .method_10977(class_124.field_1075)
                        );
                client.field_1724.method_7353(folderLink, false);
            }
        } catch (Exception e) {
            LOGGER.error("Failed to export Pokédex data", e);
            client.field_1724.method_7353(
                    class_2561.method_43470("§c[Cobblemon Collector] Pokédex export failed: " + e.getMessage()),
                    false
            );
        }
    }
}
